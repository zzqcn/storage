#include "mylib.h"

int main(void)
{
    printHello();
    return 0;
}
