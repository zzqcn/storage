#include <iostream>

int main(void)
{
    std::cout << "hello world\n";
    return 0;
}
