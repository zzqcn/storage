#include <cstdio>
#include "mylib.h"


void printHello(void)
{
    printf("hello world\n");
}
