#ifndef __MYLIB_H__
#define __MYLIB_H__

void printHello(void);

#endif
