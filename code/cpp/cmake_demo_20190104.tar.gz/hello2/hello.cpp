#include "lib/mylib.h"

int main(void)
{
    printHello();
    return 0;
}
