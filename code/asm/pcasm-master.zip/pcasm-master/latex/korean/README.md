# Korean translation

This translation was done by Jae Beom Lee.

These files don't use TeX Live distribution that the others do. See
the comments in pcasm.tex to see how to build.

