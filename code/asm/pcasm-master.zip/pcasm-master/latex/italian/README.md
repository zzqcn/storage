# Italian translation

This translation was done by Giacomo Bruschi.

It requires Italian support for the _babel_ LaTeX package. I installed
it on Ubuntu with the command:

> sudo apt install texlive-lang-italian
