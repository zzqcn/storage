# Spanish translation

This translation was done by Leonardo Rodríguez Mújica.

It requires Spanish support for the _babel_ LaTeX package. I installed
it on Ubuntu with the command:

> sudo apt install texlive-lang-spanish
