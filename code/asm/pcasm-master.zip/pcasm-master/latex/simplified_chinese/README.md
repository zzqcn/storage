# Simplified Chinese translation

This translation was done Wu Xing.

These files use CJK-LaTeX.
