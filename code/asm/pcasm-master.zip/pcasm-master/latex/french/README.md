# French translation

This translation was done by Sébastien Le Ray.

It requires French support for the _babel_ LaTeX package. I installed
it on Ubuntu with the command:

> sudo apt install texlive-lang-french
