# Example code

The code for different OS/C compilers are generated using the m4
macro processor.

To generate the files into the respective directories, run the generate.sh
script:

> ./generate.sh

